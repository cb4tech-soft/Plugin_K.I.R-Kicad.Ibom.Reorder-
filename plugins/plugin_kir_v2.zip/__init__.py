from .plugin_kir import plugin_kir

#init plugin

plugin_kir().register()
